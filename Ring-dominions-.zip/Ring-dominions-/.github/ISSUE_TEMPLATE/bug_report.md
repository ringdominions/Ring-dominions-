---
name: Bug report
about: Report something broken in Ring Dominion
title: "[BUG] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '...'
3. See error

**Expected behavior**
What you expected to happen.

**Screenshots**
If applicable, add screenshots or a screen recording.

**Device (please complete):**
- Device: [e.g. iPhone 14, Desktop]
- OS: [e.g. iOS 18, Windows 11]
- Browser: [e.g. Chrome, Safari]
- Version: [e.g. 22]

**Additional context**
Add any other context about the problem here.
